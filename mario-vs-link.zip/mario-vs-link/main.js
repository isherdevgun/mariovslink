'use strict'

//Event listeners
document.getElementById('marioBtn').addEventListener("click", setMario)
document.getElementById('linkBtn').addEventListener("click", setLink)
document.getElementById('calcAtk').addEventListener("click", calcAtk)
document.getElementById('battleStart').addEventListener("click", royaleStart)
//global Variables
let marioCount = 0
let linkCount = 0
//Functions
function setMario() {
    // Changing Elements
    document.getElementById("mainImg").src = "images/mario.png";
    document.getElementById('htmlBack').style.backgroundColor = "#ff0000";
    document.getElementById('bodyBack').style.backgroundColor = "pink";
    document.getElementById('hero').innerHTML = "The Mushroom Kingdom";
    document.getElementById('love').innerHTML = "Princess Peach";
    document.getElementById('nemesis').innerHTML = "King Bowser";
    //Processing Counter
    marioCount++;
    //Displaying Result
    document.getElementById("marioClicks").innerHTML = marioCount;
}

function setLink() {
    // Changing Elements
    document.getElementById("mainImg").src = "images/link.png";
    document.getElementById('htmlBack').style.backgroundColor = "green";
    document.getElementById('bodyBack').style.backgroundColor = "lightgreen";
    document.getElementById('hero').innerHTML = "Hyrule";
    document.getElementById('love').innerHTML = "Princess Zelda";
    document.getElementById('nemesis').innerHTML = "Ganon";
    //Processing 
    linkCount++;
    //Displaying Output
    document.getElementById("linkClicks").innerHTML = linkCount;
}

function calcAtk() {
    //Inputs
    let str1 = Number(document.getElementById("marioStr").value);
    let str2 = Number(document.getElementById("linkStr").value);
    let def1 = Number(document.getElementById("marioDef").value);
    let def2 = Number(document.getElementById("linkDef").value);
    //Processing
    let marioAttack = 2 * str1 / def2 + 5;
    let linkAttack = str2 += 15 / def1;

   marioAttack = Math.floor(marioAttack);
    linkAttack = Math.floor(linkAttack);
    //Output
    document.getElementById("linkAtk").innerHTML = Math.floor(linkAttack);
    document.getElementById("marioAtk").innerHTML = Math.floor(marioAttack);
}

function royaleStart() { // MARIO AND LINK ATTACK Inputs
    let str1 = Number(document.getElementById("marioStr").value);
    let str2 = Number(document.getElementById("linkStr").value);
    let def1 = Number(document.getElementById("marioDef").value);
    let def2 = Number(document.getElementById("linkDef").value);
    //  MARIO AND LINK ATTACK Processing
    let marioAttack = 2 * str1 / def2 + 5;
    let linkAttack = str2 += 15 / def1;

    marioAttack = Math.floor(marioAttack);
    linkAttack = Math.floor(linkAttack);
    //  MARIO AND LINK ATTACK Output
    document.getElementById("linkAtk").innerHTML = linkAttack;
    document.getElementById("marioAtk").innerHTML = marioAttack;
    //BaTTLE ROYALE INPUTS
    let marioWep = document.getElementById("marioWeapon").value
    let linkWep = document.getElementById("linkWeapon").value
    let battleshout = document.getElementById("battleCry").value
    //Creative part is that if mario's attack is higher he will win in the madlib otherwise link will win. if they are equal they both die

    if (marioAttack > linkAttack) {
        let madlib = "Mario lunged at Link and prepared his " + marioWep + " for an attack of " + marioAttack + " but Link was too quick. Link unsheathed his " + linkWep + " and struck Mario first! Mario took " + linkAttack + " damage. Mario let out a loud'" + battleshout + " and killed link with one hit!"
        document.getElementById('madLib').innerHTML = madlib;
        document.getElementById('outcome').innerHTML = "Mario Wins";
    } else if (linkAttack == marioAttack) {
        let madlib = "Mario lunged at Link and prepared his " + marioWep + " for an attack of " + marioAttack + " but Link was too quick. Link unsheathed his " + linkWep + " and struck Mario as well ! Mario took " + linkAttack + " damage. Link took" + marioAttack + " damage.Mario let out a loud'" + battleshout + "'and collapsed to the ground.Link fell with a thud."
        document.getElementById('madLib').innerHTML = madlib;
        document.getElementById('outcome').innerHTML = "They both died";
    } else {

        let madlib = "Mario lunged at Link and prepared his " + marioWep + " for an attack of " + marioAttack + " but Link was too quick. Link unsheathed his " + linkWep + " and struck Mario first! Mario took " + linkAttack + " damage. Mario let out a loud'" + battleshout + "'and collapsed to the ground."
        document.getElementById('madLib').innerHTML = madlib;
        document.getElementById('outcome').innerHTML = "Link Wins";
    }




}